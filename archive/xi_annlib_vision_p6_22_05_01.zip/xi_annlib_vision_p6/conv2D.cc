/*******************************************************************************
* Copyright (c) 2019 Cadence Design Systems, Inc.
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to use this Software with Cadence processor cores only and
* not with any other processors and platforms, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************/
#include <algorithm>
#include "include/xi_tile3d_manager.h"
#include "include/flk_conv.h"
#include "include/xi_core_api.h"
#include "utils.h"

uint32_t xiConvGetMemReqd_Context(uint32_t *pContextSize)
{
	if(pContextSize) {
		*pContextSize = sizeof(conv_params_t);
		return 0;
	}
	else return 1;
}

uint32_t xiConvGetMemReqd_Coeff(uint8_t *pContext, uint32_t contextSize, uint32_t *pCoeffSize)
{
	if ( !pContext || (contextSize < sizeof(conv_params_t)) )
		return 1;
	conv_params_t *convParams = (conv_params_t *)pContext;
	*pCoeffSize = convParams->coeff_reord_size + sizeof(int32_t) * convParams->bias_reord_size;
	return 0;
}

static size_t ConvCoefficientsBufferSize2(const conv_params_t *params)
{
    size_t coeff_size = params->kernelW * params->kernelH;
    switch (CONV_FLAG_GET_KERNEL_KIND(params->flags)) {
    case kkVQ_QM24:
    case kkVQ_QM32: {
        size_t tiles = (params->output.D + params->tile.D - 1) / params->tile.D;
        coeff_size *= align_up(params->tile.D, ALIGNMENT) * params->input.D * tiles;
        break;
    }
    case kkNone : {
        // No padding needed.
        coeff_size *= params->output.D * params->input.D;
        break;
    }
    default: {
        // No padding needed.
        printf("invalid case. Abort...\n");
        assert(0);
        break;
    }
    }
    return coeff_size;
}


typedef float (*kernel_model_f)(const conv_params_t& params);

static bool
searchTileDims(conv_params_t& params, conv_kernel_kind_e kernel_kind, int depth_step,
  kernel_model_f model, conv_mem_info_t* mem_info, float* loss = NULL, int32_t coreCount = 1, int32_t batch = 1)
{
  // Best tile size and optimization metric
  const float MAX_METRIC = 10e30;

  int H = params.output.H;
  int W = params.output.W;

  // Search for fast implementation
  CONV_FLAG_SET_KERNEL_KIND(params.flags, kernel_kind);
  CONV_FLAG_SET_DOUBLE_BUFF_COEFF(params.flags, 1);

  // See if it fits and skip search if so.
  params.tile.D = params.output.D;
  params.tile.W = params.output.W;
  params.tile.H = params.output.H;

  size_t mem_needed = AllocateLocalMemConv2D(&params, mem_info);
  if (mem_needed)
  {
    if (loss != NULL)
    {
      *loss = model(params);
    }

    return(true);
  }

  int best_W = 0;
  int best_H = 0;
  int best_D = 0;
  int HWBbest_W = 0;
  int HWBbest_H = 0;
  int HWBbest_D = 0;
  int best_double_buff = 1;
  int HWBbest_double_buff = 1;

  float best_metric = MAX_METRIC;
  float HWBbest_metric = MAX_METRIC; // Two variables to capture which way to go about in tiling if using either reload input or reload output.
  int filter_size = params.input.D * params.kernelW * params.kernelH;

  for (int double_buff = 1; double_buff >= 0; double_buff--)
  {
    CONV_FLAG_SET_DOUBLE_BUFF_COEFF(params.flags, double_buff);
    for (unsigned int D = depth_step; D <= params.output.D + depth_step - 1; D += depth_step)
    {
      params.tile.D = std::min(D, params.output.D);
      // Throw in coefficients transfer cycles, just some estimate
      float coeff_transfer = (double_buff) ? (256 + (params.tile.D * filter_size + 15) / 16) : 0;
      float tiling_overhead = 1276;
      coeff_transfer *= (params.output.D + params.tile.D - 1) / params.tile.D;
      for (int i = W + H - 1; i > 0; i--)
      {
        if (i >= W)
        {
          params.tile.W = W;
          params.tile.H = i - W + 1;
        }
        else
        {
          params.tile.W = i;
          params.tile.H = 1;
        }

        mem_needed = AllocateLocalMemConv2D(&params, mem_info);
        if (mem_needed)
        {
          float metric = mem_info->numTilesD * mem_info->numTilesW
            * mem_info->numTilesH * (tiling_overhead + model(params)) + coeff_transfer;
          if (metric < best_metric)
          {
            best_metric = metric;
            best_double_buff = double_buff;
            best_W = params.tile.W;
            best_H = params.tile.H;
            best_D = params.tile.D;
          }

          if (!((mem_info->numTilesW * mem_info->numTilesH * batch) < (uint32_t)coreCount))
          {
            if (metric < HWBbest_metric)
            {
              HWBbest_metric = metric;
              HWBbest_double_buff = double_buff;
              HWBbest_W = params.tile.W;
              HWBbest_H = params.tile.H;
              HWBbest_D = params.tile.D;
            }
          }
        }
      }
    }
  }

  if (best_metric < MAX_METRIC)
  {
    CONV_FLAG_SET_DOUBLE_BUFF_COEFF(params.flags, best_double_buff);
    params.tile.W = best_W;
    params.tile.H = best_H;
    params.tile.D = best_D;
    if (loss != NULL)
      *loss = best_metric;

    // restore local memory layout with selected params.tile/double buffering
    mem_needed = AllocateLocalMemConv2D(&params, mem_info);
    if (params.VQ7_512MAC_supported)
      return true;

    int64_t totalSpatialReloads = (mem_info->numTilesH * mem_info->numTilesW * batch);
    int64_t inputSize = (mem_info->numTilesD - 1) * (totalSpatialReloads)*mem_info->inpTileSize;
    int64_t coeffSize = mem_info->numTilesD * (totalSpatialReloads - 1) * mem_info->coeffTileSize;

    if (inputSize <= coeffSize) // Reloading inputs
    {
      CONV_FLAG_SET_DOUBLE_BUFF_COEFF(params.flags, best_double_buff);
      params.tile.W = best_W;
      params.tile.H = best_H;
      params.tile.D = best_D;
      if (loss != NULL)
        *loss = best_metric;

      // restore local memory layout with selected params.tile/double buffering
      mem_needed = AllocateLocalMemConv2D(&params, mem_info);
      return true;
    }
    else
    {
      if (HWBbest_metric < MAX_METRIC) {
        CONV_FLAG_SET_DOUBLE_BUFF_COEFF(params.flags, HWBbest_double_buff);
        params.tile.W = HWBbest_W;
        params.tile.H = HWBbest_H;
        params.tile.D = HWBbest_D;
        if (loss != NULL)
          *loss = best_metric;

        // restore local memory layout with selected params.tile/double buffering
        mem_needed = AllocateLocalMemConv2D(&params, mem_info);
        return true;
      }
      CONV_FLAG_SET_DOUBLE_BUFF_COEFF(params.flags, best_double_buff);
      params.tile.W = best_W;
      params.tile.H = best_H;
      params.tile.D = best_D;
      if (loss != NULL)
        *loss = best_metric;

      // restore local memory layout with selected params.tile/double buffering
      mem_needed = AllocateLocalMemConv2D(&params, mem_info);
      return(true);

    }
  }

  // Not selected
  return(false);
}
//Todo: UPDATE VALID MODEL
static float kernel_model_vq_qm24(const conv_params_t& params)
{
  int rows = (params.tile.W * params.tile.H + QM32_COL_PADDING - 1) / QM32_COL_PADDING;
  int channels = (params.tile.D + 2 * IVPN_SIMD_WIDTH - 1) / (2 * IVPN_SIMD_WIDTH);
  int filter_size = align_up(align_up(params.input.D * params.kernelW, QM32_ROW_PADDING) * params.kernelH, QM32_FILTER_PADDING) / sizeof(int32_t);
  return((float)((8.2 * (filter_size + 1) / 2 + 61) * channels + 115) * rows + 125);
}

static float
getVQQM24Estimate(conv_params_t& params, conv_mem_info_t* mem_info, int32_t coreCount, int32_t batch)
{
  float vq_qm24_loss = 0;
  int depth_step;
  if (params.isVQ7optimize) depth_step = 16;
  else depth_step = 1;
  if (searchTileDims(params, kkVQ_QM24, depth_step, kernel_model_vq_qm24, mem_info, &vq_qm24_loss, coreCount, batch))
  {
#if _TUNE_PERF_
    printf("BEST QM24: %f\n", vq_qm24_loss);
#endif
  }
  return(vq_qm24_loss);
}

//TODO: update with valid model
static float kernel_model_vq_qm32(const conv_params_t& params)
{
  int rows = (params.tile.W * params.tile.H + QM32_COL_PADDING - 1) / QM32_COL_PADDING;
  int channels = (params.tile.D + 2 * IVPN_SIMD_WIDTH - 1) / (2 * IVPN_SIMD_WIDTH);
  int filter_size = align_up(align_up(params.input.D * params.kernelW, QM32_ROW_PADDING) * params.kernelH, QM32_FILTER_PADDING) / sizeof(int32_t);
  int level1 = (filter_size + 61) / 62;
  int level2 = (filter_size + 1) / 2;
  return((float)((8.2 * level2 + 28 * level1 + 123) * channels + 115) * rows + 125);
}

int setupDeviceMemoryLayout(uint32_t* sizes,
  int arraysNum, localMem_info_t* localMem,
  const banks_info_t* banks_info)
{
  uint32_t    sizeA;
  uint32_t    sizeB;
  uint32_t    retAssign;
  int         i, j;
  int         reference[XTENSA_OPERATION_MAX_NUM_OPERANDS];
  uint32_t    lsizes[XTENSA_OPERATION_MAX_NUM_OPERANDS];
  banks_info_t* banksInfo = (banks_info_t*)banks_info;

  // Try to fill split banks first
  if (localMem->banksNumber == 2) {
    sizeA = 0;
    sizeB = 0;
    retAssign = 0;

    //  create a reference array and sort length array
    for (i = 0; i < arraysNum; i++) {
      // fill reference array
      reference[i] = i;
      lsizes[i] = sizes[i];
    }

    // use an insertion sort, descending order
    for (i = 1; i < arraysNum; i++) {
      uint32_t t = lsizes[i];
      uint32_t t2 = reference[i];
      for (j = i; j >= 1 && t > lsizes[j - 1]; j--) {
        lsizes[j] = lsizes[j - 1];
        reference[j] = reference[j - 1];
      }
      lsizes[j] = t;
      reference[j] = t2;
    }

    // fill banks with biggest array 1st, then next size etc
    for (i = 0; i < arraysNum; i++) {
      if (!lsizes[i])
        break;  // all zero-length (absent) arrays are at the end
      if ((sizeA + lsizes[i]) > localMem->bankSize[0]) {
        if ((sizeB + lsizes[i]) > localMem->bankSize[1])
          goto contiguous;    // failed, both banks can't fit array
        sizeB += lsizes[i];
        // set bank1 with original array index
        retAssign |= (1 << reference[i]);
        continue;
      }
      sizeA += lsizes[i];
    }
    banksInfo->banksMode = 2;   // allocation is OK, force split mode in device
    banksInfo->bankAssignments = retAssign;
    banksInfo->bank0total = sizeA;
    banksInfo->bank1total = sizeB;
    return 1;
  }

contiguous:
  // last resort... if banks are contiguous or just a single bank
  if (localMem->banksMode < 2) {
    uint32_t totalSize;
    uint32_t pastSize;
    sizeA = 0;
    retAssign = 0;
    totalSize = localMem->bankSize[0] + localMem->bankSize[1];
    for (i = 0; i < arraysNum; i++) {
      if (!sizes[i])
        continue;
      pastSize = sizeA;
      sizeA += *(sizes + i);
      if (sizeA >= totalSize) {
        return 0;   // BAD
      }
      if (pastSize >= localMem->bankSize[0])
        retAssign |= (1 << i);
    }
    banksInfo->banksMode = localMem->banksMode;
    banksInfo->bankAssignments = retAssign;
    banksInfo->bank0total = sizeA;
    return 1;
  }

  return 0;   // BAD
}

bool
SetupConv2D(conv_params_t& params, bool allow_acc24, bool channel_qflag, conv_kernel_kind_e force_kernel, conv_mem_info_t* mem_info, int32_t coreCount, int32_t batch)
{
 if (allow_acc24 && channel_qflag)
  {
    conv_params_t best_params = params;
    conv_mem_info_t best_mem_info = *mem_info;
    float best_loss = 0;
    if (force_kernel == kkNone || force_kernel == kkVQ_QM24)
    {
      float vq_qm24_loss = getVQQM24Estimate(params, mem_info, coreCount, batch);
      if (best_loss == 0 || (vq_qm24_loss > 0 && vq_qm24_loss < best_loss))
      {
        best_loss = vq_qm24_loss;
        best_params = params;
        best_mem_info = *mem_info;
      }
    }

#if 0
    // Special case of QM24 for porformance improvement
    if (force_kernel == kkNone || force_kernel == kkVQ_InvQM24)
    {
      float vq_inv_qm24_loss = getVQInvQM24Estimate(params, mem_info, coreCount, batch);
      if (best_loss == 0 || (vq_inv_qm24_loss > 0 && vq_inv_qm24_loss < best_loss))
      {
        best_loss = vq_inv_qm24_loss;
        best_params = params;
        best_mem_info = *mem_info;
      }
    }
    if (force_kernel == kkNone || force_kernel == kkVQ_GS_MOW)
    {
      float vq_mow_loss = getVQ_GS_MOWEstimate(params, mem_info, coreCount, batch);
      if (best_loss == 0 || (vq_mow_loss > 0 && vq_mow_loss < best_loss))
      {
        best_loss = vq_mow_loss;
        best_params = params;
        best_mem_info = *mem_info;
      }
    }

    if (force_kernel == kkNone || force_kernel == kkVQ_GS_MOW1x1)
    {
      float vq_mow_loss1x1 = getVQ_GS_MOW1x1Estimate(params, mem_info, coreCount, batch);
      if (best_loss == 0 || (vq_mow_loss1x1 > 0 && vq_mow_loss1x1 < best_loss))
      {
        best_loss = vq_mow_loss1x1;
        best_params = params;
        best_mem_info = *mem_info;
      }
    }

    if (force_kernel == kkNone || force_kernel == kkVQ_GS_MOW_S2)
    {
      float vq_mow_lossS2 = getVQ_GS_MOWS2Estimate(params, mem_info, coreCount, batch);
      if (best_loss == 0 || (vq_mow_lossS2 > 0 && vq_mow_lossS2 < best_loss))
      {
        best_loss = vq_mow_lossS2;
        best_params = params;
        best_mem_info = *mem_info;
      }
    }
#endif
    if (best_loss > 0)
    {
      params = best_params;
      *mem_info = best_mem_info;

      return(true);
    }
  }
  if (channel_qflag)
  {
    if (force_kernel == kkNone || force_kernel == kkVQ_QM32)
    {
      float vq_qm32_loss = 0;
      if (searchTileDims(params, kkVQ_QM32, 1, kernel_model_vq_qm32, mem_info, &vq_qm32_loss, coreCount, batch))
      {
#if _TUNE_PERF_
        printf("BEST VQ QM32: %f\n", vq_qm32_loss);
#endif
        return(true);
      }
      // Failed kkVQ_32 try kkVQ_FC
      force_kernel = kkVQ_FC;
    }
  }
  if (channel_qflag)
  {
    if (force_kernel == kkNone || force_kernel == kkVQ_FC)
    {
      // No luck, try fully connected layer
      params.tile.W = 1;
      params.tile.H = 1;

      if (CONV_FLAG_GET_FP16(params.flags))
      {
        CONV_FLAG_SET_KERNEL_KIND(params.flags, kkVQ_FC_FP16);
      }
      else
      {
        CONV_FLAG_SET_KERNEL_KIND(params.flags, kkVQ_FC);
      }

      // Allow double buffering of coefficients
      CONV_FLAG_SET_DOUBLE_BUFF_COEFF(params.flags, 1);

      for (int D = params.output.D; D > 0; D--)
      {
        params.tile.D = D;
        size_t mem_needed = AllocateLocalMemConv2D(&params, mem_info);
        if (mem_needed)
          return(true);
      }
    }
  }
  else
  {
    if (force_kernel == kkNone || force_kernel == kkFC)
    {
      //printf("No luck, try fully connected layer\n");
      // No luck, try fully connected layer
      params.tile.W = 1;
      params.tile.H = 1;

      if (CONV_FLAG_GET_FP16(params.flags))
      {
        CONV_FLAG_SET_KERNEL_KIND(params.flags, kkFC_FP16);
      }
      else
      {
        CONV_FLAG_SET_KERNEL_KIND(params.flags, kkFC);
      }

      // Allow double buffering of coefficients
      CONV_FLAG_SET_DOUBLE_BUFF_COEFF(params.flags, 1);

      for (int D = params.output.D; D > 0; D--)
      {
        params.tile.D = D;
        size_t mem_needed = AllocateLocalMemConv2D(&params, mem_info);
        if (mem_needed)
        {
          return(true);
        }
      }
    }
  }

  return(false);
}
bool MayOverflowAccumulator24(const uint8_t* filters_data,
  size_t filter_size,
  size_t count)
{
  bool overflow_possible = false;

  for (size_t filter = 0; filter < count; filter++)
  {
    uint64_t sum = 0;
    for (size_t c = 0; c < filter_size; c++)
    {
      int s8 = filters_data[filter * filter_size + c] - 128;
      sum += (s8 < 0) ? (-128 * s8) : (128 * s8);
    }
    if (sum > 0x7FFFFF)
    {
      overflow_possible = true;
      break;
    }
  }
  return(overflow_possible);
}
static void force_kernel_type(conv_params_t* p, conv_kernel_kind_e kernel, bool allow_acc24, bool channelQFlag)
{
  if (channelQFlag)
    kernel = (allow_acc24 == true) ? kkVQ_QM24 : kkVQ_QM32;
}
uint32_t xiConvSetContext(uint8_t *pContext, uint32_t contextSize, const uint32_t inputD, const uint32_t inputW, const uint32_t inputH,
		  const uint32_t outputD, const uint32_t outputW, const uint32_t outputH, const uint32_t filterW, const uint32_t filterH,
		  const uint32_t stride_width, const uint32_t zeroPtInput, const uint32_t zeroPtCoeff, const uint32_t zeroPtOutput,
		  const uint32_t quantizedScale, const uint32_t outputShift, const uint32_t reluMin, const uint32_t reluMax, uint8_t* pFilter, const uint32_t paddingWidth, const uint32_t paddingHeight)
{
  if ( !pContext || (contextSize < sizeof(conv_params_t)) )
	return 1;
  conv_params_t *convParams = (conv_params_t *)pContext;
  memset(convParams, 0, sizeof(conv_params_t));
  convParams->structSize = sizeof(conv_params_t);
  convParams->input = { inputD, inputW, inputH };
  convParams->output = { outputD, outputW, outputH };
  convParams->batch = 1;
  convParams->kernelW = filterW;
  convParams->kernelH = filterH;
  convParams->stride = stride_width;
  if (paddingWidth) {
    convParams->offsetX = 0;
  }
  else {
    convParams->offsetX = filterW / 2;
  }

  if (paddingHeight) {
    convParams->offsetY = 0;
  }
  else {
    convParams->offsetY = filterH / 2;
  }

  convParams->tileType.dataType = XI_TILE4D_U8;
  convParams->zeroPtInput = zeroPtInput;
  convParams->zeroPtCoeff = zeroPtCoeff;
  convParams->zeroPtOutput = zeroPtOutput;
  convParams->quantizedScale = quantizedScale;
  convParams->outputShift = outputShift;
  convParams->reluMin = reluMin;
  convParams->reluMax = reluMax;
  convParams->VQ7_512MAC_supported = 0;
#define CONV_FLAG_SET_RELU(flags, value)               (flags) = ((flags) & ~1) | ((value) & 1)
  CONV_FLAG_SET_RELU(convParams->flags, 1 != 1);
#define CONV_FLAG_RESET_FP16(flags)  ((flags) = (flags) & (~(1 << 11)))
  CONV_FLAG_RESET_FP16(convParams->flags);

  conv_mem_info_t mem_inf;

  conv_kernel_kind_e kernel_kind;

  mem_inf.localMem.banksNumber = arena_num_banks();
  uint32_t free_space = 0;
  arena_bank_free_space(0, &free_space);
  mem_inf.localMem.bankSize[0] = free_space;
  free_space = 0;
  arena_bank_free_space(1, &free_space);
  mem_inf.localMem.bankSize[1] = free_space;
  if (mem_inf.localMem.banksNumber < 2)
  mem_inf.localMem.banksMode = 0;
  else
  mem_inf.localMem.banksMode = 2; // ((arena_contiguous_banks())? 1 : 2);

  convParams->isVQ7optimize = 0;
  // TODO : current 'person detection' usecase can fit whole output in one tile.
  // add assert checks otherwise
  convParams->tile.D = convParams->output.D;
  convParams->tile.W = convParams->output.W;
  convParams->tile.H = convParams->output.H;
#if !(REF_FLK_CONV2D)
  kernel_kind = kkVQ_QM24;
#if 0
  if ( (convParams->input.H == 1 && convParams->input.W == 1)
		  || (convParams->input.D <= 8) )
	  CONV_FLAG_SET_KERNEL_KIND(convParams->flags, kkGS_MOW1x1);
  else
	  CONV_FLAG_SET_KERNEL_KIND(convParams->flags, kkQM24);
#endif
  bool allow_acc24 = true;
  bool ofl_flag = MayOverflowAccumulator24(pFilter, filterW * filterH * inputD, outputD);

  if (allow_acc24 && ofl_flag)
  {
    allow_acc24 = false;
    kernel_kind = kkVQ_QM32;
  }
  force_kernel_type(convParams, kernel_kind, allow_acc24, 1);
  CONV_FLAG_SET_KERNEL_KIND(convParams->flags, kernel_kind);
  SetupConv2D(*convParams, allow_acc24, 1, kernel_kind, &mem_inf, 1, convParams->batch);
  
#endif

  // Choose which input to reload if it's inevitable
  int64_t totalSpatialTiles = mem_inf.numTilesH * mem_inf.numTilesW * convParams->batch;
  int64_t reloadInput = (mem_inf.numTilesD - 1) * totalSpatialTiles * mem_inf.inpTileSize;
  int64_t reloadCoeff = mem_inf.numTilesD * (totalSpatialTiles - 1) * mem_inf.coeffTileSize;
  CONV_FLAG_SET_RELOAD_INPUT(convParams->flags, reloadInput <= reloadCoeff);

  bool kernel_F16flag = (CONV_FLAG_GET_KERNEL_KIND(convParams->flags) == kkFC_FP16);
  convParams->coeff_reord_size = (ConvCoefficientsBufferSize2(convParams) ) << kernel_F16flag;
  convParams->bias_reord_size = (convParams->output.D ) << kernel_F16flag;
  convParams->scale_size = align_up((convParams->output.D *sizeof(int32_t)), sizeof(int32_t)) << kernel_F16flag;
  convParams->shift_size = (convParams->output.D) << kernel_F16flag;

  return 0;
}

static bool
ConvReorderCoefficients2(const uint8_t *coeff_ref, const int32_t* bias_ref, uint8_t *coeff, int32_t* bias, const conv_params_t *params)
{
    int tiles_count = (params->output.D + params->tile.D - 1) / params->tile.D;

    // TODO
#if (REF_FLK_CONV2D)
    switch (kkFC) {
#else
    switch (CONV_FLAG_GET_KERNEL_KIND(params->flags)) {
#endif //(REF_FLK_CONV2D)

    case kkVQ_QM24:
    case kkVQ_QM32:{
        int8_t *coeff_s8 = (int8_t *)coeff;
        for (int tile = 0; tile < tiles_count; tile++) {
            unsigned int tile_depth = std::min(params->tile.D, params->output.D - tile * params->tile.D);
            unsigned int tile_depth64 = align_up(tile_depth, ALIGNMENT);
            //for (unsigned int n = 0; n < tile_depth; n++) {
                for (unsigned int h = 0; h < params->kernelH; h++) {
                    for (unsigned int w = 0; w < params->kernelW; w++) {
                        for (unsigned int ch = 0; ch < params->input.D; ch++) {
                            unsigned int n = 0;
                            for (; n < tile_depth; n++) {
                                int32_t idx = (((tile * params->tile.D + n)* params->kernelH + h) * params->kernelW + w) * params->input.D + ch;
                                *coeff_s8++ = (int8_t)coeff_ref[idx];
                            }
                            for (; n < tile_depth64; n++) {
                                *coeff_s8++ = 0;
                            }
                        }
                    }
                }
            //}
            // copy bias in one pass
            uint32_t src_filter_size = params->kernelH * params->kernelW * params->input.D;
            for (unsigned int d = 0; d < tile_depth; d++) {
                int fixup = 0;
                for (unsigned i = 0; i < src_filter_size; i++) {
                    fixup +=(int8_t)coeff_ref[(tile * params->tile.D  + d) * src_filter_size + i];
                }
                *bias++ = *bias_ref++ - (params->zeroPtInput * fixup);
            }
        }
        break;
    }
     default:
        return false;
    }
    return true;
}

uint32_t xiConv(uint8_t *pContext, uint32_t contextSize, int8_t * input, uint32_t inputSize, int8_t * output, uint32_t outputSize,
		int8_t *reordCoeffnBias, uint32_t reordCoeffnBiasSize, int32_t *outScale, int8_t *outShift, uint32_t num_channels)
{
	if ( !pContext || (contextSize < sizeof(conv_params_t)) )
		return 1;
	conv_params_t *convParams = (conv_params_t *)pContext;
	if (reordCoeffnBiasSize < convParams->coeff_reord_size + sizeof(int32_t) * convParams->bias_reord_size)
		return 1;

	int8_t *reordCoeff = reordCoeffnBias;
	int32_t *reordBias = (int32_t *)(reordCoeff + convParams->coeff_reord_size);

	XtensaOperationArgsIn inputs = {
	  5,
	  {input,
	  (int8_t *)reordCoeff,
      (int8_t*)reordBias,
      (int8_t*)outScale,
      (int8_t *)outShift, },
	  {inputSize, convParams->coeff_reord_size, sizeof(int32_t) * convParams->bias_reord_size, num_channels, num_channels}
	};

	struct XtensaOperationArgsOut outputs = {
	  1,
	  {output,},
	  {outputSize, }
	};

#if FLK_CYCLES
    int start = XT_RSR_CCOUNT();
#endif
#if (REF_FLK_CONV2D)
	flk_conv_ref(reinterpret_cast<const uint8_t*>(convParams), &inputs, &outputs);
#else
	flk_conv(reinterpret_cast<const uint8_t*>(convParams), &inputs, &outputs);
#endif //(REF_FLK_CONV2D)
#if FLK_CYCLES
    int stop = XT_RSR_CCOUNT();
    printf("Conv2D (including iDMA) =%d\n",stop-start);
#endif

#if !IS_MULTICHANNEL_DMA
	dma_barrier();

#if KERNEL_INFO
	printf("Conv2D:iW=%d,iH=%d,iD=%d \t kw=%d,kh=%d \t oW=%d,oH=%d,oD=%d \n", convParams->input.W, convParams->input.H, convParams->input.D, convParams->kernelW, convParams->kernelH, convParams->output.W, convParams->output.H, convParams->output.D );

#endif
#endif
	return 0;
}

uint32_t xiConvDoCoeffReorder(uint8_t *pContext, uint32_t contextSize,
		uint8_t *reordCoeffnBias, uint32_t reordCoeffnBiasSize, uint8_t *pFilter, int32_t *pBias)
{
	if ( !reordCoeffnBias || !pFilter || !pBias)
		return 1;
	if ( !pContext || (contextSize < sizeof(conv_params_t)) )
		return 1;
	conv_params_t *convParams = (conv_params_t *)pContext;
	if (reordCoeffnBiasSize < convParams->coeff_reord_size + sizeof(int32_t) * convParams->bias_reord_size)
		return 1;

	uint8_t *reordCoeff = reordCoeffnBias;
	int32_t *reordBias = (int32_t *)(reordCoeff + convParams->coeff_reord_size);
	return (uint32_t)(false == ConvReorderCoefficients2(pFilter, pBias, reordCoeff, reordBias, convParams));
}

conv_kernel_kind_e kernelKind(const conv_params_t &params) { return kkNone; }
int  allowAccumulator24() { return true; }
